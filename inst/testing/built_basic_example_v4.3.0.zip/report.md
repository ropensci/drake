---
title: Example Report
author: You
output: html_document
---

Look how I read outputs from the drake cache."
Drake notices that `small`, `coef_regression2_small`,
and `large` are dependencies of the
future compiled output report file target, `report.md`.
Just be sure that the workflow plan command for the target `'report.md'`
has an explicit call to `knit()`, something like `knit('report.Rmd')` or
`knitr::knit(input = 'report.Rmd', quiet = TRUE)`.


```r
library(drake)
readd(small)
```

```
##            x y
## 1 -0.9859866 1
## 2 -0.9178308 0
## 3  1.1105840 0
## 4 -1.5427479 2
## 5 -0.3296667 1
```

```r
readd(coef_regression2_small)
```

```
## (Intercept)          x2 
##   0.2256366   0.5186846
```

```r
loadd(large)
head(large)
```

```
##            x y
## 1 -0.7895635 1
## 2  1.9575465 1
## 3  1.2444319 1
## 4 -0.7409758 1
## 5 -0.5373366 1
## 6  2.2068733 1
```
