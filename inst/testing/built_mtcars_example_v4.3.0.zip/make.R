library(drake) # Use version 4.3.0
packageVersion("drake")
load_basic_example()
make(my_plan)
